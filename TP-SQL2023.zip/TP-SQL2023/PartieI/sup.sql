USE TP_BD_3GI;

/*-- I-7/ Suppression de la table EMPLOYEE
DROP TABLE EMPLOYEE;/*