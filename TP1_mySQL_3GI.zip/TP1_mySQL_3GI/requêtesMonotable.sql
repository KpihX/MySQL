USE Parc;

SELECT typePoste 
FROM Poste 
WHERE numPoste = 'p8';

SELECT nomLog 
FROM Logiciel 
WHERE typeLog = 'UNIX';

SELECT nomPoste, indIP, nSalle 
FROM Poste 
WHERE typePoste IN ('UNIX', 'PCWS');

SELECT nomPoste, indIP, nSalle 
FROM Poste 
WHERE indIP = '130.120.80' 
ORDER BY nSalle DESC;

SELECT nLog 
FROM Installer 
WHERE numPoste = 'p6';

SELECT numPoste 
FROM Installer 
WHERE nLog = 'log1';

SELECT CONCAT(indIP, '.', ad), nomPoste FROM Poste WHERE typePoste = 'TX';
