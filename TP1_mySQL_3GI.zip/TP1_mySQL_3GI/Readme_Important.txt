*** Devoir de BD sue mySQL ***

* Membres du groupes :
    - KAMDEM POUOKAM Ivann Harold
    - WADOH TCHINDA Pavel Devoir
    - LEMPBENG Belviane
    - DONCHY Trésor
    - DJOUNKENG Eleonor

* Précisions :
    - chaque dossier contient un fichier de requêtes sql avec éventuellement les résultats des requètes si demandés
    - Les questions ouvertes dans le TP1 sont repondues en commentaires dans les fichiers .sql