USE Parc;

-- Fonctions et groupements
-- 8. Pour chaque poste, le nombre de logiciels installés (en utilisant la table Installer)
SELECT nPoste, COUNT(nLog) AS nbLogiciels
FROM Installer
GROUP BY nPoste;

-- 9. Pour chaque salle, le nombre de postes (à partir de la table Poste)
SELECT nomSalle, COUNT(nPoste) AS nbPostes
FROM Poste
GROUP BY nomSalle;

-- 10. Pour chaque logiciel, le nombre d’installations sur des postes différents
SELECT nLog, COUNT(DISTINCT nPoste) AS nbInstallations
FROM Installer
GROUP BY nLog;

-- 11. Moyenne des prix des logiciels 'UNIX'
SELECT AVG(prix) AS moyennePrix
FROM Logiciel
WHERE typeLog = 'UNIX';

-- 12. Plus récente date d’achat d’un logiciel
SELECT MAX(dateAchat) AS derniereDate
FROM Logiciel;
