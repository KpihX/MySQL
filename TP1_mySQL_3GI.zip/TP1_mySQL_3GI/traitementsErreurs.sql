USE Parc;

-- En entrant les alter... plus bas on aura l'erreur au niveau des tuples de Salle d'adresse IP '130.120.83' et au niveau de 'BeOS' dans logiciel

DELETE FROM Salle
WHERE indIP LIKE '130.120.83';

ALTER TABLE Salle ADD CONSTRAINT fk_Salle_indIP_Segment FOREIGN KEY (indIP) REFERENCES Segment(indIP);
ALTER TABLE Logiciel ADD CONSTRAINT fk_Logiciel_typeLog_typeLP FOREIGN KEY (typeLog) REFERENCES Types(typeLP);

INSERT INTO Types (typeLP, nomType) VALUES
    ('BeOS', 'Système BeOS');
