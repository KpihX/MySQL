USE Parc;

CREATE TABLE Softs AS SELECT * FROM Logiciel;
CREATE TABLE PCSeuls AS SELECT * FROM Poste WHERE typePoste = 'PCWS' OR typePoste = 'PCNT';

SELECT * FROM Softs;
SELECT * FROM PCSeuls;
