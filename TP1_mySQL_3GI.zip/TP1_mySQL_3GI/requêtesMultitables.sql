USE Parc;

-- Requêtes multitables[^1^][1]
-- Opérateurs ensemblistes[^2^][2]
-- 15 Types de postes non recensés dans le parc informatique (utiliser la table Types)[^3^][3]
SELECT typePoste FROM Types
WHERE typePoste NOT IN (SELECT typePoste FROM Poste);

-- 16 Types existant à la fois comme types de postes et de logiciels[^4^][4]
SELECT typePoste FROM Types
WHERE typePoste IN (SELECT typeLog FROM Logiciel);[^5^][5]

-- 17 Types de postes de travail n’étant pas des types de logiciels[^4^][4]
SELECT typePoste FROM Types
WHERE typePoste NOT IN (SELECT typeLog FROM Logiciel);[^5^][5]

-- Jointures procédurales[^6^][6]
-- 18 Adresses IP complètes des postes qui hébergent le logiciel 'log6'[^7^][7]
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste, Segment
WHERE Poste.numSegment = Segment.numSegment
AND nPoste IN (SELECT nPoste FROM Installer WHERE nLog = 'log6');

-- 19 Adresses IP complètes des postes qui hébergent le logiciel de nom 'Oracle 8'[^7^][7]
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste, Segment
WHERE Poste.numSegment = Segment.numSegment
AND nPoste IN (SELECT nPoste FROM Installer, Logiciel WHERE Installer.nLog = Logiciel.nLog AND nomLog = 'Oracle 8');

-- 20 Noms des segments possédant exactement trois postes de travail de type 'TX'
SELECT nomSegment
FROM Poste, Segment
WHERE Poste.numSegment = Segment.numSegment
AND typePoste = 'TX'
GROUP BY nomSegment
HAVING COUNT(*) = 3;

-- 21 Noms des salles ou l’on peut trouver au moins un poste hébergeant le logiciel 'Oracle 6'[^8^][8]
SELECT nomSalle
FROM Salle, Poste, Installer, Logiciel
WHERE Salle.numSalle = Poste.numSalle
AND Poste.nPoste = Installer.nPoste
AND Installer.nLog = Logiciel.nLog
AND nomLog = 'Oracle 6'
GROUP BY nomSalle;

-- 22 Nom du logiciel acheté le plus récent (utiliser la requête 12)[^9^][9]
SELECT nomLog
FROM Logiciel
WHERE dateAchat = (SELECT MAX(dateAchat) FROM Logiciel);

-- Jointures relationnelles
-- Écrire les requêtes 18, 19, 20, 21 avec des jointures de la forme relationnelle[^10^][10][^11^][11]
-- Numéroter ces nouvelles requêtes de 23 à 26[^12^][12]

-- 23 Adresses IP complètes des postes qui hébergent le logiciel 'log6'
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste, Segment, Installer
WHERE Poste.numSegment = Segment.numSegment
AND Poste.nPoste = Installer.nPoste
AND Installer.nLog = 'log6';

-- 24 Adresses IP complètes des postes qui hébergent le logiciel de nom 'Oracle 8'[^7^][7]
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste, Segment, Installer, Logiciel
WHERE Poste.numSegment = Segment.numSegment
AND Poste.nPoste = Installer.nPoste
AND Installer.nLog = Logiciel.nLog
AND Logiciel.nomLog = 'Oracle 8';

-- 25 Noms des segments possédant exactement trois postes de travail de type 'TX'
SELECT nomSegment
FROM Poste, Segment
WHERE Poste.numSegment = Segment.numSegment
AND Poste.typePoste = 'TX'
GROUP BY nomSegment
HAVING COUNT(*) = 3;

-- 26 Noms des salles ou l’on peut trouver au moins un poste hébergeant le logiciel 'Oracle 6'[^8^][8]
SELECT nomSalle
FROM Salle, Poste, Installer, Logiciel
WHERE Salle.numSalle = Poste.numSalle
AND Poste.nPoste = Installer.nPoste
AND Installer.nLog = Logiciel.nLog
AND Logiciel.nomLog = 'Oracle 6'
GROUP BY nomSalle;

-- 27 Installations (nom segment, nom salle, adresse IP complète, nom logiciel, date d’installation) triées par segment, salle et adresse IP[^12^][12]
SELECT nomSegment, nomSalle, CONCAT(nomSegment, '.', ad) AS ip, nomLog, dateIns
FROM Segment, Salle, Poste, Installer, Logiciel
WHERE Segment.numSegment = Salle.numSegment
AND Salle.numSalle = Poste.numSalle
AND Poste.nPoste = Installer.nPoste
AND Installer.nLog = Logiciel.nLog
ORDER BY nomSegment, nomSalle, ip;

-- Jointures SQL2[^13^][13]
-- Écrire les requêtes 18, 19, 20, 21 avec des jointures SQL2 (JOIN, NATURAL JOIN, JOIN USING)[^11^][11][^10^][10]
-- Numéroter ces nouvelles requêtes de 28 à 31[^14^][14]

-- 28 Adresses IP complètes des postes qui hébergent le logiciel 'log6'[^7^][7]
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste NATURAL JOIN Segment
JOIN Installer USING (nPoste)
WHERE nLog = 'log6';

-- 29 Adresses IP complètes des postes qui hébergent le logiciel de nom 'Oracle 8'
SELECT CONCAT(nomSegment, '.', ad) AS ip
FROM Poste NATURAL JOIN Segment
JOIN Installer USING (nPoste)
JOIN Logiciel USING (nLog)
WHERE nomLog = 'Oracle 8';

-- 30 Noms des segments possédant exactement trois postes de travail de type 'TX'
SELECT nomSegment
FROM Poste NATURAL JOIN Segment
WHERE typePoste = 'TX'
GROUP BY nomSegment
HAVING COUNT(*) = 3;

-- 31 Noms des salles ou l’on peut trouver au moins un poste hébergeant le logiciel 'Oracle 6'
SELECT nomSalle
FROM Salle NATURAL JOIN Poste
JOIN Installer USING (nPoste)
JOIN Logiciel USING (nLog)
WHERE nomLog = 'Oracle 6'
GROUP BY nomSalle;
